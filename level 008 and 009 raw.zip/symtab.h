#pragma once

#include "llvm_includes.h"
#include <map>
#include <string>

extern std::unique_ptr<llvm::LLVMContext> TheContext;
extern std::unique_ptr<llvm::Module>      TheModule;
extern std::unique_ptr<llvm::IRBuilder<>> Builder;

class SymbolTable {
public:
    llvm::AllocaInst* declare(const std::string& name, llvm::Function* fn) {
        auto it = table_.find(name);
        if (it != table_.end()) return it->second;

        llvm::IRBuilder<> eb(&fn->getEntryBlock(),
                              fn->getEntryBlock().begin());
        llvm::AllocaInst* alloca =
            eb.CreateAlloca(llvm::Type::getInt32Ty(*TheContext),
                            nullptr, name);
        table_[name] = alloca;
        return alloca;
    }

    llvm::AllocaInst* lookup(const std::string& name) const {
        auto it = table_.find(name);
        return (it != table_.end()) ? it->second : nullptr;
    }

    void clear() { table_.clear(); }

private:
    std::map<std::string, llvm::AllocaInst*> table_;
};

extern SymbolTable SymTab;
