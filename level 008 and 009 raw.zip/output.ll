; ModuleID = 'calc_module'
source_filename = "calc_module"

@fmt = private unnamed_addr constant [4 x i8] c"%d\0A\00", align 1

define i32 @main() {
entry:
  %b = alloca i32, align 4
  %a = alloca i32, align 4
  store i32 0, ptr %a, align 4
  store i32 0, ptr %b, align 4
  br i1 true, label %and.rhs, label %and.false

and.rhs:                                          ; preds = %entry
  %a1 = load i32, ptr %a, align 4
  %eq = icmp eq i32 %a1, 0
  br i1 %eq, label %or.true, label %or.rhs

and.false:                                        ; preds = %entry
  br label %and.end

and.end:                                          ; preds = %or.end, %and.false
  %and.res = phi i1 [ false, %and.false ], [ %or.res, %or.end ]
  br i1 %and.res, label %if.then, label %if.else

or.rhs:                                           ; preds = %and.rhs
  %b2 = load i32, ptr %b, align 4
  %eq3 = icmp eq i32 %b2, 1
  br label %or.end

or.true:                                          ; preds = %and.rhs
  br label %or.end

or.end:                                           ; preds = %or.rhs, %or.true
  %or.res = phi i1 [ true, %or.true ], [ %eq3, %or.rhs ]
  br label %and.end

if.then:                                          ; preds = %and.end
  %0 = call i32 (ptr, ...) @printf(ptr @fmt, i32 99)
  br label %if.end

if.else:                                          ; preds = %and.end
  br label %if.end

if.end:                                           ; preds = %if.else, %if.then
  ret i32 0
}

declare i32 @printf(ptr, ...)
