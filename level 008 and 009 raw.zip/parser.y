%{
/* ============================================================
 *  parser.y  —  Level 008 + 009  (final clean version)
 * ============================================================ */
#include "llvm_includes.h"
#include "symtab.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>

std::unique_ptr<llvm::LLVMContext> TheContext;
std::unique_ptr<llvm::Module>      TheModule;
std::unique_ptr<llvm::IRBuilder<>> Builder;
SymbolTable SymTab;

static llvm::Function* MainFn   = nullptr;
static llvm::Function* PrintfFn = nullptr;

int  yylex(void);
void yyerror(const char* s) { fprintf(stderr,"Parser error: %s\n",s); }

/* Emit printf("%d\n", val) — val must be i32 */
static void emitPrint(llvm::Value* v) {
    llvm::Value* fmt = Builder->CreateGlobalStringPtr("%d\n","fmt");
    Builder->CreateCall(PrintfFn,{fmt,v});
}

/* Extend i1 → i32 so we can print booleans */
static llvm::Value* boolToInt(llvm::Value* v) {
    return Builder->CreateZExt(v, llvm::Type::getInt32Ty(*TheContext), "b2i");
}

static llvm::BasicBlock* newBB(const char* n) {
    return llvm::BasicBlock::Create(*TheContext,n,MainFn);
}

/* ── Simple block-info stack for nested if/while ─────────────
 * Each entry holds the BasicBlock pointers for one control
 * structure.  We use a small hand-rolled stack so mid-rule
 * actions can pass data to their parent rule without relying
 * on Bison's fragile $<>-N relative indexing.
 */
struct CtrlFrame {
    llvm::BasicBlock* bb[4];   /* generic slots */
};

static CtrlFrame ctrl_stack[128];
static int       ctrl_top = 0;

static void ctrl_push(llvm::BasicBlock* a=nullptr,
                      llvm::BasicBlock* b=nullptr,
                      llvm::BasicBlock* c=nullptr,
                      llvm::BasicBlock* d=nullptr) {
    ctrl_stack[ctrl_top] = {a,b,c,d};
    ctrl_top++;
}
static CtrlFrame ctrl_pop() { return ctrl_stack[--ctrl_top]; }
static CtrlFrame& ctrl_peek() { return ctrl_stack[ctrl_top-1]; }
%}

%union {
    int           ival;
    char*         sval;
    llvm::Value*  val;
    llvm::Value*  bval;
}

%token <ival> INTEGER
%token <sval> IDENT
%token NEWLINE IF ELSE WHILE LE GE EQ NE AND OR

%type <val>  expr
%type <bval> bexpr

/* Dangling-else: shift ELSE rather than reduce (binds to nearest if) */
%precedence IF_NO_ELSE
%precedence ELSE
/* Boolean precedence */
%left  OR
%left  AND
%right '!'
/* Relational */
%left  EQ NE
%left  '<' '>' LE GE
/* Arithmetic */
%left  '+' '-'
%left  '*' '/'
%right UMINUS

%%

program : %empty | program stmt ;

/* ════════════════════════════════════════════════════════════
   Statements
   ════════════════════════════════════════════════════════════ */
stmt
    /* ── assignment ─────────────────────────────────────────── */
    : IDENT '=' expr ';' {
        llvm::AllocaInst* slot = SymTab.declare($1,MainFn);
        Builder->CreateStore($3,slot);
        free($1);
      }

    /* ── expression-statement (print result) ─────────────────── */
    | expr ';'  { emitPrint($1); }
    | bexpr ';' { emitPrint(boolToInt($1)); }

    /* ── block ───────────────────────────────────────────────── */
    | '{' stmtlist '}'

    /* ── IF-THEN (no else) ───────────────────────────────────── *
     *
     *   if_setup:  evaluates bexpr, creates then/else/merge BBs,
     *              emits CondBr, pushes frame, moves to then_bb.
     *
     *   After then-body:
     *     close then_bb → merge_bb
     *     fill  else_bb → merge_bb   (no code in else)
     *     continue in merge_bb
     *
     *   Layout:
     *     pre ──CondBr──► then_bb ──br──► merge_bb
     *                  └─► else_bb ──br──► merge_bb
     */
    | if_setup stmt %prec IF_NO_ELSE {
        CtrlFrame f = ctrl_pop();
        llvm::BasicBlock* else_bb  = f.bb[1];
        llvm::BasicBlock* merge_bb = f.bb[2];

        /* Close then-block */
        if (!Builder->GetInsertBlock()->getTerminator())
            Builder->CreateBr(merge_bb);

        /* Fill empty else-block */
        Builder->SetInsertPoint(else_bb);
        Builder->CreateBr(merge_bb);

        Builder->SetInsertPoint(merge_bb);
      }

    /* ── IF-THEN-ELSE ─────────────────────────────────────────── *
     *
     *   if_setup → then body → else_setup → else body → done
     *
     *   else_setup:
     *     closes then_bb → merge_bb
     *     moves Builder into else_bb
     *
     *   Layout:
     *     pre ──CondBr──► then_bb ──br──► merge_bb
     *                  └─► else_bb ──br──► merge_bb
     */
    | if_setup stmt else_setup stmt {
        CtrlFrame f = ctrl_pop();
        llvm::BasicBlock* merge_bb = f.bb[2];

        /* Close else-block */
        if (!Builder->GetInsertBlock()->getTerminator())
            Builder->CreateBr(merge_bb);

        Builder->SetInsertPoint(merge_bb);
      }

    /* ── WHILE ────────────────────────────────────────────────── *
     *
     *   while_setup:
     *     creates cond_bb, body_bb, after_bb
     *     emits: pre → br → cond_bb
     *     evaluates bexpr in cond_bb
     *     emits CondBr(cond, body_bb, after_bb) in cond_bb
     *     moves Builder into body_bb
     *     pushes frame {cond_bb, body_bb, after_bb}
     *
     *   After body:
     *     close body_bb → cond_bb   (loop-back)
     *     continue in after_bb
     *
     *   Layout:
     *     pre ──br──► cond_bb ──T──► body_bb ──br──► cond_bb
     *                         └──F──► after_bb
     */
    | while_setup stmt {
        CtrlFrame f = ctrl_pop();
        llvm::BasicBlock* cond_bb  = f.bb[0];
        llvm::BasicBlock* after_bb = f.bb[2];

        /* Loop-back edge */
        if (!Builder->GetInsertBlock()->getTerminator())
            Builder->CreateBr(cond_bb);

        Builder->SetInsertPoint(after_bb);
      }

    | NEWLINE { }
    | ';'     { }
    ;

stmtlist : %empty | stmtlist stmt ;

/* ── if_setup mid-rule ──────────────────────────────────────── *
 *  Parses: IF '(' bexpr ')'
 *  Side effects:
 *    - Creates then_bb, else_bb, merge_bb
 *    - Emits CondBr(bexpr, then_bb, else_bb) in current block
 *    - Pushes { then_bb, else_bb, merge_bb } onto ctrl_stack
 *    - Moves Builder into then_bb
 */
if_setup
    : IF '(' bexpr ')' {
        llvm::BasicBlock* then_bb  = newBB("if.then");
        llvm::BasicBlock* else_bb  = newBB("if.else");
        llvm::BasicBlock* merge_bb = newBB("if.end");

        Builder->CreateCondBr($3, then_bb, else_bb);
        ctrl_push(then_bb, else_bb, merge_bb);
        Builder->SetInsertPoint(then_bb);
      }
    ;

/* ── else_setup mid-rule ────────────────────────────────────── *
 *  Parses: ELSE
 *  Side effects:
 *    - Reads frame from ctrl_stack (without popping)
 *    - Closes then_bb with br → merge_bb
 *    - Moves Builder into else_bb
 */
else_setup
    : ELSE {
        CtrlFrame& f = ctrl_peek();
        llvm::BasicBlock* else_bb  = f.bb[1];
        llvm::BasicBlock* merge_bb = f.bb[2];

        if (!Builder->GetInsertBlock()->getTerminator())
            Builder->CreateBr(merge_bb);

        Builder->SetInsertPoint(else_bb);
      }
    ;

/* ── while_setup mid-rule ─────────────────────────────────────── *
 *  Parses: WHILE '(' bexpr ')'
 *  Side effects:
 *    - Creates cond_bb, body_bb, after_bb
 *    - Emits: current → br → cond_bb
 *    - Evaluates bexpr while Builder is in cond_bb
 *    - Emits CondBr(bexpr, body_bb, after_bb) in cond_bb
 *    - Pushes { cond_bb, body_bb, after_bb }
 *    - Moves Builder into body_bb
 */
while_setup
    : WHILE '(' {
        /* Create all blocks BEFORE evaluating bexpr so that
         * the condition instructions land in cond_bb.         */
        llvm::BasicBlock* cond_bb  = newBB("while.cond");
        llvm::BasicBlock* body_bb  = newBB("while.body");
        llvm::BasicBlock* after_bb = newBB("while.after");

        /* Jump from pre-loop block into the condition block */
        Builder->CreateBr(cond_bb);
        Builder->SetInsertPoint(cond_bb);

        /* Push now so the second mid-rule can pop/read it */
        ctrl_push(cond_bb, body_bb, after_bb);
      }
      bexpr ')' {
        /* bexpr ($4) was emitted in cond_bb — emit the branch */
        CtrlFrame& f = ctrl_peek();
        llvm::BasicBlock* body_bb  = f.bb[1];
        llvm::BasicBlock* after_bb = f.bb[2];

        Builder->CreateCondBr($4, body_bb, after_bb);
        Builder->SetInsertPoint(body_bb);
      }
    ;

/* ════════════════════════════════════════════════════════════
   Boolean expressions  →  i1
   ════════════════════════════════════════════════════════════ */
bexpr
    /* ── Relational operators (Level 008) ──────────────────── */
    : expr '<' expr  { $$ = Builder->CreateICmpSLT($1,$3,"lt"); }
    | expr '>' expr  { $$ = Builder->CreateICmpSGT($1,$3,"gt"); }
    | expr LE  expr  { $$ = Builder->CreateICmpSLE($1,$3,"le"); }
    | expr GE  expr  { $$ = Builder->CreateICmpSGE($1,$3,"ge"); }
    | expr EQ  expr  { $$ = Builder->CreateICmpEQ ($1,$3,"eq"); }
    | expr NE  expr  { $$ = Builder->CreateICmpNE ($1,$3,"ne"); }

    /* ── Short-circuit AND  (Level 009) ────────────────────── *
     *
     *  sc_and:
     *    - Runs after lhs bexpr is known ($<bval>-1 on stack)
     *    - Creates: rhs_bb, sc_false_bb, merge_bb
     *    - Emits:   CondBr(lhs, rhs_bb, sc_false_bb)
     *               sc_false_bb: br merge_bb
     *    - Moves Builder → rhs_bb
     *    - Pushes { rhs_bb, sc_false_bb, merge_bb }
     *
     *  Final action:
     *    - rhs bexpr ($4) is done in Builder's current block
     *    - Close rhs block → merge_bb
     *    - PHI in merge_bb: { false←sc_false, rhs←rhs_end }
     */
    | bexpr AND sc_and bexpr {
        CtrlFrame f = ctrl_pop();
        llvm::BasicBlock* rhs_end     = Builder->GetInsertBlock();
        llvm::BasicBlock* sc_false_bb = f.bb[1];
        llvm::BasicBlock* merge_bb    = f.bb[2];

        if (!rhs_end->getTerminator())
            Builder->CreateBr(merge_bb);

        Builder->SetInsertPoint(merge_bb);
        llvm::PHINode* phi = Builder->CreatePHI(
            llvm::Type::getInt1Ty(*TheContext), 2, "and.res");
        phi->addIncoming(llvm::ConstantInt::getFalse(*TheContext), sc_false_bb);
        phi->addIncoming($4, rhs_end);
        $$ = phi;
      }

    /* ── Short-circuit OR  (Level 009) ─────────────────────── *
     *
     *  sc_or:
     *    - Runs after lhs bexpr
     *    - Creates: rhs_bb, sc_true_bb, merge_bb
     *    - Emits:   CondBr(lhs, sc_true_bb, rhs_bb)
     *               sc_true_bb: br merge_bb
     *    - Moves Builder → rhs_bb
     *    - Pushes { rhs_bb, sc_true_bb, merge_bb }
     *
     *  PHI in merge_bb: { true←sc_true, rhs←rhs_end }
     */
    | bexpr OR sc_or bexpr {
        CtrlFrame f = ctrl_pop();
        llvm::BasicBlock* rhs_end    = Builder->GetInsertBlock();
        llvm::BasicBlock* sc_true_bb = f.bb[1];
        llvm::BasicBlock* merge_bb   = f.bb[2];

        if (!rhs_end->getTerminator())
            Builder->CreateBr(merge_bb);

        Builder->SetInsertPoint(merge_bb);
        llvm::PHINode* phi = Builder->CreatePHI(
            llvm::Type::getInt1Ty(*TheContext), 2, "or.res");
        phi->addIncoming(llvm::ConstantInt::getTrue(*TheContext), sc_true_bb);
        phi->addIncoming($4, rhs_end);
        $$ = phi;
      }

    /* ── Logical NOT (Level 009) ─────────────────────────────── */
    | '!' bexpr { $$ = Builder->CreateNot($2,"not"); }

    | '(' bexpr ')' { $$ = $2; }
    ;

/* sc_and mid-rule: after lhs bexpr, before rhs bexpr */
sc_and
    : %empty {
        llvm::BasicBlock* rhs_bb      = newBB("and.rhs");
        llvm::BasicBlock* sc_false_bb = newBB("and.false");
        llvm::BasicBlock* merge_bb    = newBB("and.end");

        Builder->CreateCondBr($<bval>-1, rhs_bb, sc_false_bb);

        Builder->SetInsertPoint(sc_false_bb);
        Builder->CreateBr(merge_bb);

        Builder->SetInsertPoint(rhs_bb);

        ctrl_push(rhs_bb, sc_false_bb, merge_bb);
      }
    ;

/* sc_or mid-rule: after lhs bexpr, before rhs bexpr */
sc_or
    : %empty {
        llvm::BasicBlock* rhs_bb     = newBB("or.rhs");
        llvm::BasicBlock* sc_true_bb = newBB("or.true");
        llvm::BasicBlock* merge_bb   = newBB("or.end");

        Builder->CreateCondBr($<bval>-1, sc_true_bb, rhs_bb);

        Builder->SetInsertPoint(sc_true_bb);
        Builder->CreateBr(merge_bb);

        Builder->SetInsertPoint(rhs_bb);

        ctrl_push(rhs_bb, sc_true_bb, merge_bb);
      }
    ;

/* ════════════════════════════════════════════════════════════
   Arithmetic expressions  →  i32
   ════════════════════════════════════════════════════════════ */
expr
    : INTEGER {
        $$ = llvm::ConstantInt::get(*TheContext,llvm::APInt(32,$1,true));
      }
    | IDENT {
        llvm::AllocaInst* slot = SymTab.lookup($1);
        if (!slot) {
            fprintf(stderr,"Error: '%s' used before assignment\n",$1);
            $$ = llvm::ConstantInt::get(*TheContext,llvm::APInt(32,0,true));
        } else {
            $$ = Builder->CreateLoad(
                     llvm::Type::getInt32Ty(*TheContext),slot,$1);
        }
        free($1);
      }
    | expr '+' expr  { $$ = Builder->CreateAdd ($1,$3,"add"); }
    | expr '-' expr  { $$ = Builder->CreateSub ($1,$3,"sub"); }
    | expr '*' expr  { $$ = Builder->CreateMul ($1,$3,"mul"); }
    | expr '/' expr  { $$ = Builder->CreateSDiv($1,$3,"div"); }
    | '(' expr ')'   { $$ = $2; }
    | '-' expr %prec UMINUS {
        $$ = Builder->CreateSub(
            llvm::ConstantInt::get(*TheContext,llvm::APInt(32,0,true)),
            $2,"neg");
      }
    ;

%%

/* ════════════════════════════════════════════════════════════
   main()
   ════════════════════════════════════════════════════════════ */
int main() {
    TheContext = std::make_unique<llvm::LLVMContext>();
    TheModule  = std::make_unique<llvm::Module>("calc_module",*TheContext);
    Builder    = std::make_unique<llvm::IRBuilder<>>(*TheContext);

    /* Define i32 @main() */
    llvm::FunctionType* mainTy =
        llvm::FunctionType::get(llvm::Type::getInt32Ty(*TheContext),false);
    MainFn = llvm::Function::Create(
        mainTy,llvm::Function::ExternalLinkage,"main",*TheModule);

    llvm::BasicBlock* entry =
        llvm::BasicBlock::Create(*TheContext,"entry",MainFn);
    Builder->SetInsertPoint(entry);

    /* Declare printf: i32(ptr, ...) */
    llvm::FunctionType* printfTy =
        llvm::FunctionType::get(
            llvm::Type::getInt32Ty(*TheContext),
            {llvm::PointerType::getUnqual(*TheContext)},
            /*isVarArg=*/true);
    PrintfFn = llvm::cast<llvm::Function>(
        TheModule->getOrInsertFunction("printf",printfTy).getCallee());

    /* Parse — grammar actions emit IR inline */
    yyparse();

    /* Terminate main */
    if (!Builder->GetInsertBlock()->getTerminator())
        Builder->CreateRet(
            llvm::ConstantInt::get(*TheContext,llvm::APInt(32,0,true)));

    /* Verify */
    std::string errStr;
    llvm::raw_string_ostream errStream(errStr);
    if (llvm::verifyModule(*TheModule,&errStream)) {
        fprintf(stderr,"Module verification failed:\n%s\n",errStr.c_str());
        return 1;
    }

    /* Write output.ll */
    std::error_code EC;
    llvm::raw_fd_ostream out("output.ll",EC,llvm::sys::fs::OF_Text);
    if (EC) { fprintf(stderr,"Cannot open output.ll\n"); return 1; }
    TheModule->print(out,nullptr);
    fprintf(stderr,"IR written to output.ll\n");
    fprintf(stderr,"Run: lli-15 output.ll\n");
    return 0;
}
